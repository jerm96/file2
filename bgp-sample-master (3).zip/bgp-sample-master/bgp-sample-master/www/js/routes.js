angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('login', {
    url: '/page1',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('mainPage', {
    url: '/page2',
    templateUrl: 'templates/mainPage.html',
    controller: 'mainPageCtrl'
  })

  .state('signup', {
    url: '/page3',
    templateUrl: 'templates/signup.html',
    controller: 'signupCtrl'
  })

  .state('settings', {
    url: '/page4',
    templateUrl: 'templates/settings.html',
    controller: 'settingsCtrl'
  })

  .state('premiumSubscription', {
    url: '/page5',
    templateUrl: 'templates/premiumSubscription.html',
    controller: 'premiumSubscriptionCtrl'
  })

  .state('ME', {
    url: '/page8',
    templateUrl: 'templates/ME.html',
    controller: 'MECtrl'
  })

  .state('dISCOVER', {
    url: '/page9',
    templateUrl: 'templates/dISCOVER.html',
    controller: 'dISCOVERCtrl'
  })

  .state('sING', {
    url: '/page10',
    templateUrl: 'templates/sING.html',
    controller: 'sINGCtrl'
  })

  .state('sINGNOW', {
    url: '/page11',
    templateUrl: 'templates/sINGNOW.html',
    controller: 'sINGNOWCtrl'
  })

  .state('myKaraoke', {
    url: '/page12',
    templateUrl: 'templates/myKaraoke.html',
    controller: 'myKaraokeCtrl'
  })

  .state('allSongs', {
    url: '/page13',
    templateUrl: 'templates/allSongs.html',
    controller: 'allSongsCtrl'
  })

  .state('pLAYINGFROMPLAYLIST', {
    url: '/page14',
    templateUrl: 'templates/pLAYINGFROMPLAYLIST.html',
    controller: 'pLAYINGFROMPLAYLISTCtrl'
  })

  .state('forgotEmailPassword', {
    url: '/page15',
    templateUrl: 'templates/forgotEmailPassword.html',
    controller: 'forgotEmailPasswordCtrl'
  })

  .state('passwordReset', {
    url: '/page16',
    templateUrl: 'templates/passwordReset.html',
    controller: 'passwordResetCtrl'
  })

  .state('findUsername', {
    url: '/page17',
    templateUrl: 'templates/findUsername.html',
    controller: 'findUsernameCtrl'
  })

  .state('emailConfirmation', {
    url: '/page18',
    templateUrl: 'templates/emailConfirmation.html',
    controller: 'emailConfirmationCtrl'
  })

$urlRouterProvider.otherwise('/page1')


});